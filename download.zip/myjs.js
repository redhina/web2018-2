//alert('Hello, Hinano!');
//alert(1+1);
alert(Math.sqrt(1+1));
2+3
'2'+'3'
Number('2')+Number('3')
'2'+3
Number('2')+3

