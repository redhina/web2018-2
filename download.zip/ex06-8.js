function sayhello68() {
alert('Hello,' + document.getElementByld('who').innerHTML + '!');
}
function taro() {
 document.getElementByld('who').innerHTML + '太郎';
}
function hanako() {
 document.getElementByld('who').innerHTML + '花子';
}