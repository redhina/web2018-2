var who='world';
function sayhello() {
   alert('Hello,'+ who + '!');
}
function　太郎(){
  who='taro';
}
