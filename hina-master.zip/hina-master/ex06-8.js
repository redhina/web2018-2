function sayhello68() {
alert('Hello,' + document.getElementByld('who').innerHTML + '!');
}
function 太郎() {
 document.getElementByld('who').innerHTML + 'taro';
}
function 花子() {
 document.getElementByld('who').innerHTML + 'hanako';
}