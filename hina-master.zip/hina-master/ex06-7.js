var who ='world';
function sayhello() {
alert('hello,' + who + '!');
}
function someone(x) {
who = x;
}